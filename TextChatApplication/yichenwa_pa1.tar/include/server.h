#ifndef SERVER_H_
#define SERVER_H_


void setup_Server(int myport);
char* ipfunction_Server();
#endif
           
