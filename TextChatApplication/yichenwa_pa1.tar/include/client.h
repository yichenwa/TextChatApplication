#ifndef CLIENT_H_
#define CLIENT_H_

char* ipfunction_Client();
void setup_Client(int client_port);



#endif
